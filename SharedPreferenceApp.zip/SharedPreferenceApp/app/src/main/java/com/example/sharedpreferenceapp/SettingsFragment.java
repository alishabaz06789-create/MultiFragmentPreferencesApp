package com.example.sharedpreferenceapp;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Switch;
import android.widget.Spinner;
import android.widget.ArrayAdapter;
import android.widget.Toast;

public class SettingsFragment extends Fragment {

    EditText etUsername, etEmail, etPassword;
    Spinner spinnerTheme;
    Switch switchNotification;
    Button btnSave, btnReset;

    SharedPreferences sharedPreferences;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.fragment_settings, container, false);

        etUsername = view.findViewById(R.id.etUsername);
        etEmail = view.findViewById(R.id.etEmail);
        etPassword = view.findViewById(R.id.etPassword);
        spinnerTheme = view.findViewById(R.id.spinnerTheme);
        switchNotification = view.findViewById(R.id.switchNotification);
        btnSave = view.findViewById(R.id.btnSave);
        btnReset = view.findViewById(R.id.btnReset);

        // Spinner items
        String themes[] = {"Light", "Dark", "Blue", "Green"};
        ArrayAdapter<String> adp = new ArrayAdapter<>(getActivity(),
                android.R.layout.simple_spinner_dropdown_item, themes);
        spinnerTheme.setAdapter(adp);

        // SharedPreferences init
        sharedPreferences = getActivity().getSharedPreferences("MyPrefs", Context.MODE_PRIVATE);

        loadPreviousValues();

        btnSave.setOnClickListener(v -> saveData());
        btnReset.setOnClickListener(v -> resetData());

        return view;
    }

    private void loadPreviousValues() {
        etUsername.setText(sharedPreferences.getString("username", ""));
        etEmail.setText(sharedPreferences.getString("email", ""));
        etPassword.setText(sharedPreferences.getString("password", ""));

        String savedTheme = sharedPreferences.getString("theme", "Light");
        spinnerTheme.setSelection(((ArrayAdapter) spinnerTheme.getAdapter()).getPosition(savedTheme));

        boolean notif = sharedPreferences.getBoolean("notification", false);
        switchNotification.setChecked(notif);
    }

    private void saveData() {
        String username = etUsername.getText().toString();
        String email = etEmail.getText().toString();
        String password = etPassword.getText().toString();
        String theme = spinnerTheme.getSelectedItem().toString();
        boolean notifications = switchNotification.isChecked();

        // validation
        if (TextUtils.isEmpty(username) ||
                TextUtils.isEmpty(email) ||
                TextUtils.isEmpty(password)) {

            Toast.makeText(getActivity(), "Please fill all fields", Toast.LENGTH_SHORT).show();
            return;
        }

        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString("username", username);
        editor.putString("email", email);
        editor.putString("password", password);
        editor.putString("theme", theme);
        editor.putBoolean("notification", notifications);
        editor.apply();

        Toast.makeText(getActivity(), "Preferences Saved!", Toast.LENGTH_SHORT).show();
    }

    private void resetData() {
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.clear();
        editor.apply();

        etUsername.setText("");
        etEmail.setText("");
        etPassword.setText("");
        spinnerTheme.setSelection(0);
        switchNotification.setChecked(false);

        Toast.makeText(getActivity(), "Preferences Reset!", Toast.LENGTH_SHORT).show();
    }
}
