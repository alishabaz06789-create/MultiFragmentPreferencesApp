package com.example.sharedpreferenceapp;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

public class ProfileFragment extends Fragment {

    TextView tvUsername, tvEmail, tvPassword, tvTheme, tvNotification, tvTitle;
    LinearLayout profileLayout;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.fragment_profile, container, false);

        tvUsername = view.findViewById(R.id.tvUsername);
        tvEmail = view.findViewById(R.id.tvEmail);
        tvPassword = view.findViewById(R.id.tvPassword);
        tvTheme = view.findViewById(R.id.tvTheme);
        tvNotification = view.findViewById(R.id.tvNotification);
        tvTitle = view.findViewById(R.id.tvTitle);
        profileLayout = view.findViewById(R.id.profileLayout);

        SharedPreferences prefs = getActivity().getSharedPreferences("MyPrefs", Context.MODE_PRIVATE);

        tvUsername.setText("Username: " + prefs.getString("username", "N/A"));
        tvEmail.setText("Email: " + prefs.getString("email", "N/A"));
        tvPassword.setText("Password: " + prefs.getString("password", "N/A"));
        tvTheme.setText("Theme: " + prefs.getString("theme", "N/A"));

        boolean notif = prefs.getBoolean("notification", false);
        tvNotification.setText("Notifications: " + (notif ? "Enabled" : "Disabled"));

        applyTheme(prefs.getString("theme", "Light"));

        return view;
    }

    // Changing background based on theme
    private void applyTheme(String theme) {
        if (theme.equals("Light")) {
            profileLayout.setBackgroundColor(Color.parseColor("#FFFFFF"));
            tvTitle.setTextColor(Color.parseColor("#000000"));
        }
        else if (theme.equals("Dark")) {
            profileLayout.setBackgroundColor(Color.parseColor("#222222"));
            tvTitle.setTextColor(Color.parseColor("#FFFFFF"));
        }
        else if (theme.equals("Blue")) {
            profileLayout.setBackgroundColor(Color.parseColor("#2196F3"));
            tvTitle.setTextColor(Color.parseColor("#FFFFFF"));
        }
        else if (theme.equals("Green")) {
            profileLayout.setBackgroundColor(Color.parseColor("#4CAF50"));
            tvTitle.setTextColor(Color.parseColor("#FFFFFF"));
        }
    }
}
